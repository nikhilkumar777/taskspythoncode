from django.db import models

# Create your models here.
class Employ(models.Model):
    emp_id=models.IntegerField(max_length=60)
    emp_name = models.CharField(max_length=60)
    manager_name = models.CharField(max_length=60)
    def __str__(self):
        return self.emp_name