from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets

from .serializers import EmploySerializer
from .models import Employ


class EmployViewSet(viewsets.ModelViewSet):
    queryset = Employ.objects.all().order_by('emp_id')
    serializer_class = EmploySerializer