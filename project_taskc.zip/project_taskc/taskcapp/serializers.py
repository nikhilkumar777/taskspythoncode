from rest_framework import serializers

from .models import Employ

class EmploySerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Employ
        fields = ('emp_id', 'emp_name','manager_name')