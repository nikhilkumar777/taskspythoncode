from django.apps import AppConfig


class TaskcappConfig(AppConfig):
    name = 'taskcapp'
